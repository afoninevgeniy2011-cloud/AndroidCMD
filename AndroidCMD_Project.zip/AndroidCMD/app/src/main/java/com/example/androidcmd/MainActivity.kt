package com.example.androidcmd

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var output: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private var prompt = "C:\\>"
    private var foreground = Color.rgb(0, 255, 70)
    private var background = Color.BLACK
    private var currentDir = "C:\\"
    private var runningDemo = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(background)
            isVerticalScrollBarEnabled = true
        }
        output = TextView(this).apply {
            setTextColor(foreground)
            typeface = Typeface.create("monospace", Typeface.NORMAL)
            textSize = 14f
            setTextIsSelectable(true)
            setPadding(dp(2), dp(2), dp(2), dp(12))
            text = "Microsoft Windows [Version 10.0.19045.4046]\n(c) Корпорация Майкрософт (Microsoft Corporation). Все права защищены.\n\n"
        }
        scroll.addView(output, ScrollView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val commandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(2))
        }
        val promptView = TextView(this).apply {
            text = "$prompt "
            setTextColor(foreground)
            typeface = Typeface.MONOSPACE
            textSize = 16f
        }
        input = EditText(this).apply {
            setSingleLine(true)
            setTextColor(foreground)
            setHintTextColor(Color.GRAY)
            hint = "Введите команду..."
            textSize = 16f
            typeface = Typeface.MONOSPACE
            setBackgroundColor(Color.rgb(18, 18, 18))
            setPadding(dp(8), dp(2), dp(8), dp(2))
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_SEND ||
                    (event != null && event.keyCode == android.view.KeyEvent.KEYCODE_ENTER &&
                     event.action == android.view.KeyEvent.ACTION_DOWN)) {
                    executeInput()
                    true
                } else false
            }
        }
        val send = Button(this).apply {
            text = "↵"
            textSize = 20f
            setOnClickListener { executeInput() }
        }
        commandRow.addView(promptView)
        commandRow.addView(input, LinearLayout.LayoutParams(0, dp(48), 1f))
        commandRow.addView(send, LinearLayout.LayoutParams(dp(54), dp(48)))
        root.addView(commandRow)
        setContentView(root)
        printPrompt()
    }

    private fun executeInput() {
        val cmd = input.text.toString().trim()
        input.setText("")
        if (cmd.isEmpty()) { printPrompt(); return }
        append("$prompt$cmd\n", Color.LTGRAY)
        val lower = cmd.lowercase(Locale.ROOT)
        when {
            lower == "cls" || lower == "clear" -> output.text = ""
            lower.startsWith("color ") -> setColor(cmd.substringAfter(' ').trim())
            lower == "dir" || lower == "dir /s" || lower.startsWith("dir ") -> showDir(lower.contains("/s"))
            lower == "help" -> help()
            lower == "ver" -> append("Microsoft Windows [Version 10.0.19045.4046]\n")
            lower == "whoami" -> append("android\\user\n")
            lower == "cd" -> append("$currentDir\n")
            lower.startsWith("cd ") -> changeDir(cmd.substringAfter(' ').trim())
            lower.startsWith("echo ") -> append(cmd.substringAfter(' ') + "\n")
            lower == "date" -> append(SimpleDateFormat("EEE dd.MM.yyyy", Locale.getDefault()).format(Date()) + "\n")
            lower == "time" -> append(SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()) + "\n")
            lower == "exit" -> append("Выход из симулятора недоступен. Можно закрыть приложение кнопкой «Назад».\n")
            lower == "tree" -> append("C:\\n+---Windows\n|   +---System32\n+---Users\n    +---Public\n    +---Documents\n")
            else -> append("'$cmd' не является внутренней или внешней командой,\nисполняемой программой или пакетным файлом.\n")
        }
        if (lower != "cls" && lower != "clear") append("\n")
        printPrompt()
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setColor(code: String) {
        if (code.length != 2 || code.any { it.lowercaseChar() !in "0123456789abcdef" }) {
            append("Неверный параметр. Используйте, например: color 0a\n"); return
        }
        background = colorFor(code[0])
        foreground = colorFor(code[1])
        output.setTextColor(foreground)
        output.setBackgroundColor(background)
        scroll.setBackgroundColor(background)
        input.setTextColor(foreground)
        (scroll.parent as? View)?.setBackgroundColor(background)
    }

    private fun colorFor(c: Char): Int = when (c.lowercaseChar()) {
        '0' -> Color.BLACK
        '1' -> Color.rgb(0, 0, 128)
        '2' -> Color.rgb(0, 128, 0)
        '3' -> Color.rgb(0, 128, 128)
        '4' -> Color.rgb(128, 0, 0)
        '5' -> Color.rgb(128, 0, 128)
        '6' -> Color.rgb(128, 128, 0)
        '7' -> Color.LTGRAY
        '8' -> Color.GRAY
        '9' -> Color.BLUE
        'a' -> Color.GREEN
        'b' -> Color.CYAN
        'c' -> Color.RED
        'd' -> Color.MAGENTA
        'e' -> Color.YELLOW
        else -> Color.WHITE
    }

    private fun showDir(recursive: Boolean) {
        val folders = listOf("$Recycle.Bin", "Documents and Settings", "Program Files",
            "Program Files (x86)", "Windows", "Users", "temp", "Recovery")
        append(" Том в устройстве C имеет метку Windows\n Серийный номер тома: 1A2B-3C4D\n\n")
        append(" Содержимое папки $currentDir\n\n")
        folders.forEach { append("27.10.2026  14:37    <DIR>          $it\n") }
        append("               0 файлов              0 байт\n")
        append("               8 папок     123 456 789 012 байт свободно\n")
        if (recursive) {
            val paths = listOf("Windows", "Windows\\System32", "Windows\\System32\\drivers",
                "Windows\\Logs", "Windows\\Temp", "Users", "Users\\Public",
                "Users\\Public\\Documents", "Program Files", "Program Files\\Common Files",
                "Program Files (x86)", "Documents and Settings", "Recovery", "temp")
            // Long, scrollable simulated listing; bounded so the app stays responsive.
            for (round in 1..30) {
                for (path in paths) {
                    append("\n Содержимое папки C:\\$path\n\n")
                    val names = listOf(".", "..", "addins", "appcompat", "AppPatch", "assembly",
                        "Boot", "Branding", "CbsTemp", "Containers", "CSC", "Cursors",
                        "debug", "DevMode", "Diagnostics", "drivers", "en-US", "Logs", "Temp")
                    names.forEach { name ->
                        append("27.10.2026  14:37    <DIR>          $name\n")
                    }
                    append("               0 файлов              0 байт\n")
                    append("              19 папок     987 654 321 098 байт свободно\n")
                }
            }
            append("\n[Симуляция завершена: показан большой пример вывода dir /s.]\n")
        }
    }

    private fun changeDir(path: String) {
        if (path == "..") currentDir = currentDir.substringBeforeLast('\\', "C:") + "\\"
        else if (path.matches(Regex("(?i)[a-z]:\\\\?"))) currentDir = path.trimEnd('\\') + "\\"
        else currentDir = currentDir.trimEnd('\\') + "\\" + path.trim('\\')
        prompt = currentDir + ">"
    }

    private fun help() {
        append("Доступные команды симулятора:\n")
        append("  color 0a  - чёрный фон, зелёный текст\n")
        append("  dir       - список папок\n")
        append("  dir /s    - длинный рекурсивный список (симуляция)\n")
        append("  cls       - очистить экран\n  cd        - текущая папка\n")
        append("  cd имя    - сменить отображаемую папку\n  tree      - дерево папок\n")
        append("  ver, date, time, echo текст, whoami, help\n")
        append("Внимание: это имитация Windows CMD, команды не выполняются в Windows.\n")
    }

    private fun printPrompt() {
        // Prompt is rendered in the input row, not duplicated in output.
        val row = input.parent as? LinearLayout
        val label = row?.getChildAt(0) as? TextView
        label?.text = "$prompt "
    }

    private fun append(text: String, color: Int = foreground) {
        output.append(text)
        // Color changes apply to the current console; individual command echo stays light gray.
        output.setTextColor(foreground)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
